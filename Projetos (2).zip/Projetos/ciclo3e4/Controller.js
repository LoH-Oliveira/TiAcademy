const express = require('express');
const {Sequelize} = require('./models');
const models = require('./models')



const app = express();
app.use(express.json());
app.use(cors())

let Cliente = models.Cliente;
let itempedido = models.ItemPedidos;
let pedido = models.Pedidos;
let servico = models.Servico;

app.get('/', function(req, res){
    res.send('Olá, mundo!')
});
app.post('/Clientes', async(req, res)=>{
    await cliente.create(
        req.body
    ).then(cli =>{
        return res.json({
            error: false,
            message: "Cliente foi inserido com sucesso.",
            cli
        }).catch(erro =>{
            return res.statusCode(400).json({
                error: true,
                message:"Não foi possivel inserir o cliente."
            })

        })
    });
    res.send('Sejam bem-vindo(a) a Services TI')
});
app.get('/Pedidos', function(req, res){
    res.send('Aqui estão os pedidos')
});
app.post('/servico', async(req, res)=>{
    await servico.create(
        req.body
    ).then(function(){
        return res.json({
            error: false,
            message: "Serviço criado com sucesso!" 
        })
    }).catch(function(erro){
        return res.status(400).json({
            error: true,
            message: "Foi impossivel se conectar."
        })
    });

});



let port = process.env.PORT || 3001;

app.listen(port,(req, res)=>{
    console.log('Servidor ativo: http://localhost:3001');
})