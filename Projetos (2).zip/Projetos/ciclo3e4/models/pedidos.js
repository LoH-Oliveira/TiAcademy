'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Pedidos extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Pedidos.belongsTo(models.Cliente,{
        foreignKey: 'ClienteId', as: 'clientes'});

      Pedidos.belongsToMany(models.Servico, {foreignKey: 'ServicoId',
        through: 'ItemPedidos', as: 'servico_ped'
      });

      Pedidos.hasMany(models.ItemPedidos, {
        foreignKey: 'PedidoId', as: 'item_pedidos'});
    
    }
  };
  Pedidos.init({
    data: DataTypes.DATEONLY,
    ClienteId: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Pedidos',
  });
  return Pedidos;
};