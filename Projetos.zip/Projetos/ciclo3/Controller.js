const express = require('express');
const models = require('./models');
const cors = require ('cors');

const app = express();
app.use(cors());
app.use(express,json());

let Cliente = models.Cliente;
let itempedido = models.ItemPedidos;
let pedido = models.Pedidos;
let servico = models.Servico;
let compra = models.Compra;
let produto = models.Produtos;
let itemcompra = models.ItemCompra;

app.get('/', function(req, res){
    res.send('Olá, mundo!')
});
app.get('/Clientes', function(req, res){
    res.send('Sejam bem-vindo(a) a Services TI')
});
app.get('/Pedidos', function(req, res){
    res.send('Aqui estão os pedidos')
});
app.post('/Servico', async(req, res)=>{
    await servico.create({
        req.body
    })
    res.send('Serviço criado com sucesso')
});

app.get('/Compra', function(req, res){
    res.send('Aqui está a compra');
});

    app.post('/Produtos', async(req, res)=>{
        await produtos.create({
            nome: "NodeJs",
            descricao: "Desenvolvimento back-and ",
            creaAt: new Date(),
            updateAt: new Date() })
        res.send('Produtos adicionados com sucesso!')
        });


let port = process.env.PORT || 3001;

app.listen(port,(req,res)=>{
    console.log('Servidor ativo: http://localhost:3001');
})